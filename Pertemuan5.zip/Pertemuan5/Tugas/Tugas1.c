#include <stdio.h>
#include <ctype.h>

int main()
{
    char e;

    printf("Input Karakter\n");
    e = getchar();

    printf("Inputan karakter adalah: ");
    putchar(e);
}
